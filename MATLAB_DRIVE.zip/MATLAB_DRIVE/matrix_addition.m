function C = matrix_addition(A, B)
% This function accepts two 3x3 matrices and returns their sum
% Check if matrices match in size for safety
if isequal(size(A), size(B))
    C = A + B;
else
    error('Matrices must be of the same dimensions for addition.');
end
end