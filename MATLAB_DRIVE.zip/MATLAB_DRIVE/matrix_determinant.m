function d = matrix_determinant(A)
% This function accepts a 3x3 matrix and returns its scalar determinant

% Compute the determinant using MATLAB's built-in optimized function
d = det(A);

% Round slightly to 4 decimal places to clean up floating-point artifacts
d = round(d, 4);
end