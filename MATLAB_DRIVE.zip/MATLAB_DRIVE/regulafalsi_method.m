function [history, roots] = regulafalsi_method(f_str, xl, xu, dx)
    f = str2func(['@(x) ', vectorize(char(f_str))]);
    history = {};
    roots = [];
    
    if f(xl) * f(xu) > 0
        return;
    end
    
    xr_old = xl;
    for iter = 1:50
        f_xl = f(xl);
        f_xu = f(xu);
        
        % False Position chord intersection formula
        xr = (xu * f_xl - xl * f_xu) / (f_xl - f_xu);
        f_xr = f(xr);
        test = f_xl * f_xr;
        
        ea = NaN;
        if iter > 1
            ea = abs((xr - xr_old) / xr) * 100;
        end
        
        % Columns: Iteration, xL, xU, xR, Ea (%), f(xL), f(xU), f(xR), f(xL)*f(xR)
        history = [history; {iter, round(xl,4), round(xu,4), round(xr,4), ...
                             round(ea,4), round(f_xl,5), round(f_xu,5), round(f_xr,5), round(test,5)}];
                             
        if (~isnan(ea) && ea <= dx) || f_xr == 0
            roots = [roots, xr];
            break;
        end
        
        if test < 0
            xu = xr;
        elseif test > 0
            xl = xr;
        else
            roots = [roots, xr];
            break;
        end
        xr_old = xr;
    end
    
    if isempty(roots), roots = [roots, xr]; end
end