function C = matrix_power(A, n)
    % This function accepts a 3x3 matrix A and an exponent n.
    % It calculates BOTH standard matrix power and element-wise power safely!
    
    % Check if the power input is empty or invalid
    if isempty(n) || ~isscalar(n)
        error('Please enter a valid scalar integer for the power.');
    end
    
    try
        % Option A: Linear Algebra Matrix Power (e.g., A * A * A)
        % This requires n to be an integer.
        C = A^n; 
        
    catch
        % Option B: Element-wise fallback (.^) 
        % If A^n fails due to dimension limits, we square/power each item individually!
        disp('Falling back to element-wise power calculation.');
        C = A.^n;
    end
    
    % Clean up floating-point precision noise
    C = round(C, 4);
end