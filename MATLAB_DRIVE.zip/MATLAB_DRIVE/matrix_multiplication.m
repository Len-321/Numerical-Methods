function C = matrix_multiplication(A, B)
% This function accepts two 3x3 matrices and returns their dot product product
% Check if matrices match dimensions for inner matrix multiplication multiplication
if size(A, 2) == size(B, 1)
    C = A * B; % Standard matrix multiplication operator in MATLAB
else
    error('Inner dimensions must match for matrix multiplication.');
end
end