function [history, roots] = incremental_method(f_str, xl, xu_limit, dx)
    % Convert the string equation to a mathematical function
    if ischar(f_str) || isstring(f_str)
        f = str2func(['@(x) ', vectorize(char(f_str))]);
    else
        f = f_str;
    end
    
    history = {};
    roots = [];
    iter = 0;
    x_curr = xl;
    
    % Search across the interval until the upper limit is reached
    while x_curr < xu_limit
        iter = iter + 1;
        
        x_next = x_curr + dx;
        f_left = f(x_curr);
        f_right = f(x_next);
        test = f_left * f_right;
        
        if test > 0
            % No sign change, keep searching forward
            remark = 'Go to next interval';
            history = [history; {iter, round(x_curr,4), round(dx,4), round(x_next,4), ...
                                 round(f_left,5), round(f_right,5), round(test,5), remark}];
            
            x_curr = x_next; % Shift lower bound to current upper bound
            
        elseif test < 0
            % Sign change detected! Root is bracketed.
            remark = 'Revert back to xl & consider smaller interval';
            history = [history; {iter, round(x_curr,4), round(dx,4), round(x_next,4), ...
                                 round(f_left,5), round(f_right,5), round(test,5), remark}];
                             
            % Estimate the root as the midpoint of this final bracket
            roots = [roots, (x_curr + x_next) / 2];
            break; % Stop searching once the bracket is found
            
        else
            % Exact root falls perfectly on a boundary
            remark = 'Exact root found';
            history = [history; {iter, round(x_curr,4), round(dx,4), round(x_next,4), ...
                                 round(f_left,5), round(f_right,5), round(test,5), remark}];
            if f_left == 0
                roots = [roots, x_curr];
            else
                roots = [roots, x_next];
            end
            break;
        end
    end
end