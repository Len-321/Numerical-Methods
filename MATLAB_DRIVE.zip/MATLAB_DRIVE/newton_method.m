function [history, roots] = newton_method(f_str, xi, dx)
    f = str2func(['@(x) ', vectorize(char(f_str))]);
    history = {};
    roots = [];
    step = 1e-5; % Small step for numerical derivative
    
    % Iteration 0 baseline matching textbook table setup
    f_xi = f(xi);
    df_xi = (f(xi + step) - f(xi - step)) / (2 * step);
    history = [history; {0, round(xi,4), NaN, round(f_xi,5), round(df_xi,5)}];
    
    for iter = 1:50
        if abs(df_xi) < 1e-12, break; end % Prevent division by zero
        
        xi_next = xi - (f_xi / df_xi);
        ea = abs((xi_next - xi) / xi_next) * 100;
        
        xi = xi_next;
        f_xi = f(xi);
        df_xi = (f(xi + step) - f(xi - step)) / (2 * step);
        
        % Columns: Iteration, xi, Ea (%), f(xi), f'(xi)
        history = [history; {iter, round(xi,4), round(ea,4), round(f_xi,5), round(df_xi,5)}];
        
        if ea <= dx
            roots = [roots, xi];
            break;
        end
    end
    
    if isempty(roots), roots = [roots, xi]; end
end