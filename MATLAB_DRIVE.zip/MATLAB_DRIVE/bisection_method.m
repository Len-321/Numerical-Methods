function [history, roots] = bisection_method(f_str, xl, xu, dx)
    f = str2func(['@(x) ', vectorize(char(f_str))]);
    history = {};
    roots = [];
    
    % Return early if bounds do not bracket a root
    if f(xl) * f(xu) > 0
        return; 
    end
    
    xr_old = xl;
    for iter = 1:50
        xr = (xl + xu) / 2;
        f_xl = f(xl);
        f_xr = f(xr);
        test = f_xl * f_xr;
        
        ea = NaN;
        if iter > 1
            ea = abs((xr - xr_old) / xr) * 100;
        end
        
        if test < 0
            remark = '1st subinterval';
        elseif test > 0
            remark = '2nd subinterval';
        else
            remark = 'Exact root';
        end
        
        % Columns: Iteration, xl, xr, xu, f(xl), f(xr), |Ea| %, f(xl)*f(xr), Remark
        history = [history; {iter, round(xl,4), round(xr,4), round(xu,4), ...
                             round(f_xl,5), round(f_xr,5), round(ea,4), round(test,5), remark}];
                             
        if (~isnan(ea) && ea <= dx) || f_xr == 0
            roots = [roots, xr];
            break;
        end
        
        if test < 0
            xu = xr;
        elseif test > 0
            xl = xr;
        else
            roots = [roots, xr];
            break;
        end
        xr_old = xr;
    end
    
    if isempty(roots), roots = [roots, xr]; end
end