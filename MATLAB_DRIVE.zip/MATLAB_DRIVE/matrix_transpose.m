function C = matrix_transpose(A)
% This function accepts a 3x3 matrix and returns its transpose

% Use MATLAB's native transpose operator (.')
C = A.';
end