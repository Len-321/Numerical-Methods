function C = matrix_inverse(A)
% This function accepts a 3x3 matrix and returns its Inverse Matrix

% Check the determinant to ensure the matrix is invertible
determinant = det(A);

if abs(determinant) < 1e-12
    % If the determinant is zero, an inverse does not mathematically exist
    error('The matrix is singular and cannot be inverted (Determinant is 0).');
else
    % Compute standard matrix inverse using MATLAB's native operator
    C = inv(A);

    % Round slightly to 4 decimal places to erase minor floating-point noise
    C = round(C, 4);
end
end