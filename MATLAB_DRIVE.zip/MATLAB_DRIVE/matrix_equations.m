function result = matrix_equations(A, B, eq_str)
    % 1. Convert the input to a standard character array
    eq_str = char(eq_str);
    
    % 2. Map lowercase 'a' and 'b' so the user doesn't have to worry about caps lock
    a = A;
    b = B;
    
    % 3. Check if the field is empty
    if isempty(strtrim(eq_str))
        error('The equation field is empty. Please type an equation like A + B.');
    end
    
    % 4. Try to evaluate the math
    try
        result = eval(eq_str);
        
        % Ensure the result is actually a matrix (in case they typed something weird)
        if ~isnumeric(result)
            error('The equation did not result in a numeric matrix.');
        end
        
    catch ME
        % If it fails, print MATLAB's EXACT error message so you know what you typed wrong
        error(['Invalid math syntax. ', newline, ...
               'MATLAB Error: ', ME.message, newline, ...
               'Remember: Use * for multiplication (e.g., 2*A, not 2A).']);
    end
end