function C = matrix_adjoint(A)
% This function accepts a 3x3 matrix and returns its Adjoint matrix
% Formula: adj(A) = det(A) * inv(A)

% Check if the matrix is invertible (det is not 0)
if abs(det(A)) > 1e-12
    C = det(A) * inv(A);
    % Round slightly to clean up floating-point precision issues
    C = round(C, 4); 
else
    % For singular matrices, calculate using the minor cofactors manually
    C = zeros(3);
    for i = 1:3
        for j = 1:3
            % Get the 2x2 submatrix by removing row i and column j
            sub_A = A;
            sub_A(i, :) = [];
            sub_A(:, j) = [];
            % Calculate cofactor value
            C(j, i) = ((-1)^(i+j)) * det(sub_A); 
        end
    end
end
end